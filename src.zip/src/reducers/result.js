import * as gameActions from '../actions/status';
import * as resultActions from '../actions/result';

import { PLAYER_ID } from '../constants/player';

const { START_GAME, START_SET, START_PLAY } = gameActions;
const { SHOW_ROCK_PAPER_SCISSORS } = resultActions;

const initialStatePlay = Object.values(PLAYER_ID).reduce((acc, curId) => {
    const newPlay = { ...acc }
    newPlay[curId] = null;
    return newPlay;
}, {})

const initialState = {
    play: initialStatePlay,
    set: [],
    game: [],
};

const resultReducer = (state = initialState, action) => {
    const { type, payload } = action;
    
    console.log('reducer-',type,payload);

    switch (type) {
        case START_GAME:
            return {
                ...state,
                game: [],
            };
        case START_SET:
            return {
                ...state,
                set: [],
            };
        case START_PLAY:
            return {
                ...state,
                play: {
                    player1: null,
                    player2: null,
                }
            };
        case SHOW_ROCK_PAPER_SCISSORS:
            const newPlay = { ...state.play };
            newPlay[payload.playerId] = payload.rockPaperScissorsType;
            return {
                ...state,
                play: newPlay,
            };
        default:
            return state;
    }
};

export default resultReducer;