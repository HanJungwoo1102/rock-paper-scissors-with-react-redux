export const ROCK_PAPER_SCISSORS = {
    ROCK: 'ROCK',
    PAPER: 'PAPER',
    SCISSORS: 'SCISSORS',
};

export const ROCK_PAPER_SCISSORS_IMAGE = {
    ROCK: 'https://www.google.com/imgres?imgurl=https%3A%2F%2Fimages.homedepot-static.com%2FproductImages%2F94af8836-0338-4802-914e-04cc71e562ad%2Fsvn%2Fbackyard-x-scapes-fake-rocks-hdd-rof-rocsb-64_1000.jpg&imgrefurl=https%3A%2F%2Fwww.homedepot.com%2Fp%2FBackyard-X-Scapes-9-in-H-x-13-in-W-x-16-in-L-Small-Fiberglass-Rock-Cover-in-Beige-HDD-ROF-ROCSB%2F100631149&tbnid=wIsPoxsTqUZ8fM&vet=12ahUKEwio1_jtudLnAhXMCt4KHaPJCsEQMygAegUIARDbAQ..i&docid=Y76U7Ladq3rrtM&w=1000&h=1000&q=rock&ved=2ahUKEwio1_jtudLnAhXMCt4KHaPJCsEQMygAegUIARDbAQ',
    PAPER: 'https://www.google.com/imgres?imgurl=https%3A%2F%2F4.imimg.com%2Fdata4%2FUL%2FHL%2FMY-18120183%2F75-gsm-a4-copier-paper-1079606-500x500.jpg&imgrefurl=https%3A%2F%2Fwww.indiamart.com%2Fapinnovations%2Fsublimation-printing-papers.html&tbnid=qzHGgbHfFIrJ5M&vet=12ahUKEwjyz9aLutLnAhXJBt4KHZxgBV4QMygLegUIARDxAQ..i&docid=NXjh-DYLyaUqLM&w=500&h=500&q=paper&ved=2ahUKEwjyz9aLutLnAhXJBt4KHZxgBV4QMygLegUIARDxAQ',
    SCISSORS: 'https://www.google.com/imgres?imgurl=https%3A%2F%2Frukminim1.flixcart.com%2Fimage%2F704%2F704%2Fjj1qrgw0%2Fscissor%2Fh%2Fg%2Fh%2Fsmooth-hair-cutting-scissor-stainless-steel-shoptop-original-imaf6h7q3rm7zgh7.jpeg%3Fq%3D70&imgrefurl=https%3A%2F%2Fwww.flipkart.com%2Fshoptop-smooth-hair-cutting-scissor-scissors%2Fp%2Fitmf6zup7wzhf2tj%3Fpid%3DSCIF6H83DU2RNHGH%26lid%3DLSTSCIF6H83DU2RNHGHMJOQWR%26marketplace%3DFLIPKART%26srno%3Db_1_19%26otracker%3Dbrowse%26fm%3Dorganic%26iid%3Dba34261b-5b2c-4c8a-81df-b95f265a477d.SCIF6H83DU2RNHGH.SEARCH&tbnid=SWi7xEhwtMoPFM&vet=12ahUKEwj407uRutLnAhXLCN4KHV7vCNgQMygBegUIARDTAQ..i&docid=AhVUlQWAGhVIFM&w=495&h=704&q=scissors&ved=2ahUKEwj407uRutLnAhXLCN4KHV7vCNgQMygBegUIARDTAQ',
}