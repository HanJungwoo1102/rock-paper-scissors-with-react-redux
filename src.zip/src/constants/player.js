export const PLAYER_ID = {
    PLAYER1: 'player1',
    PLAYER2: 'player2',
}