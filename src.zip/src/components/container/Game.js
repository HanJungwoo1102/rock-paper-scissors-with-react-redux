import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import Play from './Play';

export default () => {
    const dispatch = useDispatch();
    const { game, set, play } = useSelector((state) => state.result);
    console.log('result = ', game, set, play);
    return (
        <Play/>
    );
};
