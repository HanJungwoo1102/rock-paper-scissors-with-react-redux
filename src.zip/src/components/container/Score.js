import React from 'react';
import { useSelector } from 'react-redux';

export default () => {
    const { game, set } = useSelector((state) => state.result);

    return (
        <>
            {
                game && game.map(set => {
                    return (
                        <>
                            <div>set 승리</div>
                            {
                                set.map((play) => {
                                    const { player1, player2 } = play;
                                    return (
                                        <div>{player1} {player2}</div>
                                    );
                                })
                            }
                        </>
                    );
                })
            }
            <div>현재 set</div>
            {
                set && set.map((play) => {
                    const { player1, player2 } = play;
                    return (
                        <div>{player1} {player2}</div>
                    );
                })
            }
        </>
    );
};