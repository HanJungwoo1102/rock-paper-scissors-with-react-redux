import React, { useState, useEffect, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import * as gameActions from '../../actions/status';
import * as resultActions from '../../actions/result';

import Player from '../presentaitional/Player';
import Circle from '../presentaitional/Circle';
import CardPannel from '../presentaitional/CardPannel';
import PlayTimeManager from './PlayTimeManager';

import { ROCK_PAPER_SCISSORS } from '../../constants/rock-paper-scissors';
import { PLAYER_ID } from '../../constants/player';
import { isDraw } from '../../lib/rock-paper-scissors';

const MAX_PLAY_TIME = 30;

export default ({ playIdx }) => {
    const dispatch = useDispatch();
    const { play: playResult } = useSelector((state) => state.result);
    const { play: playStatus } = useSelector((state) => state.status);

    const endTimeHandler = useCallback(() => {
        dispatch(gameActions.endGame());
    }, []);

    const rockClickHandler = useCallback(() => {
        dispatch(resultActions.showRockPaperScissors(PLAYER_ID.PLAYER1, ROCK_PAPER_SCISSORS.ROCK));
    }, []);

    const paperClickHandler = useCallback(() => {
        dispatch(resultActions.showRockPaperScissors(PLAYER_ID.PLAYER1, ROCK_PAPER_SCISSORS.PAPER));
    }, []);

    const scissorsClickHandler = useCallback(() => {
        dispatch(resultActions.showRockPaperScissors(PLAYER_ID.PLAYER1, ROCK_PAPER_SCISSORS.SCISSORS))
    }, []);

    useEffect(() => {
        dispatch(gameActions.startPlay());
    }, [playIdx]);

    return (
        <PlayTimeManager
            isStart={playStatus.isStart}
            maxPlayTime={MAX_PLAY_TIME}
            endTimeHandler={endTimeHandler}
        >
            <Player name='PLAYER 1'>
                <Circle show={playResult[PLAYER_ID.PLAYER1]} />
                <CardPannel
                    rockClickHandler={() => dispatch(resultActions.showRockPaperScissors(PLAYER_ID.PLAYER1, ROCK_PAPER_SCISSORS.ROCK))}
                    paperClickHandler={() => dispatch(resultActions.showRockPaperScissors(PLAYER_ID.PLAYER1, ROCK_PAPER_SCISSORS.PAPER))}
                    scissorsClickHandler={() => dispatch(resultActions.showRockPaperScissors(PLAYER_ID.PLAYER1, ROCK_PAPER_SCISSORS.SCISSORS))}
                />
            </Player>
            <Player name='PLAYER 2'>
                <Circle show={playResult[PLAYER_ID.PLAYER2]} />
            </Player>
        </PlayTimeManager>
    );
};
