import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import Count from '../presentaitional/Count';

export default ({ isStart, maxPlayTime, endTimeHandler, children }) => {
    return (
        <>
            <Count count={3} />
            {
                children
            }
        </>
    );
};
