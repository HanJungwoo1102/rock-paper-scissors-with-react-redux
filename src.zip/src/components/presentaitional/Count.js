import React from 'react';

export default ({ count }) => {
    return (
        <div>{count}</div>
    );
};