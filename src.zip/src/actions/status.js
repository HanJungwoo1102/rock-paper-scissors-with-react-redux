// action types
export const START_GAME = 'game/START_GAME';
export const END_GAME = 'game/END_GAME';

export const START_SET = 'game/START_SET';
export const END_SET = 'game/END_SET';

export const START_PLAY = 'game/START_PLAY';
export const END_PLAY = 'game/END_PLAY';

// action creator
export const startGame = () => {
    return {
        type: START_GAME,
    };
};

export const endGame = () => {
    return {
        type: END_GAME,
    };
};

export const startSet = () => {
    return {
        type: START_SET,
    };
};

export const endSet = () => {
    return {
        type: END_SET,
    };
};

export const startPlay = () => {
    return {
        type: START_PLAY,
    };
};

export const endPlay = () => {
    return {
        type: END_PLAY,
    };
};

